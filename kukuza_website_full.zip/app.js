const app=document.getElementById("app");
const DB={
user:{name:"Kidy Papy",email:"user@example.com",balance:0},
services:[
{id:1,name:"Instagram Followers",cat:"Instagram",price:19000,min:100,max:1000000},
{id:2,name:"Instagram Likes",cat:"Instagram",price:7500,min:100,max:500000},
{id:3,name:"TikTok Views",cat:"TikTok",price:4000,min:100,max:1000000},
{id:4,name:"TikTok Followers",cat:"TikTok",price:17000,min:100,max:500000},
{id:5,name:"YouTube Views",cat:"YouTube",price:12000,min:100,max:500000},
{id:6,name:"YouTube Subscribers",cat:"YouTube",price:25000,min:100,max:100000}
],
orders:[
{id:"#1008",service:"Instagram Followers",qty:1000,status:"Processing",link:"instagram.com/example",date:"Today"},
{id:"#1007",service:"Instagram Likes",qty:500,status:"Completed",link:"instagram.com/example",date:"Yesterday"},
{id:"#1006",service:"TikTok Views",qty:10000,status:"Pending",link:"tiktok.com/example",date:"Yesterday"}
],
tickets:[]
};
const money=n=>"TSh "+Number(n).toLocaleString("en-US");
const esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
function toast(s){const t=document.querySelector(".toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function route(){return location.hash.replace("#","")||"dashboard"}
function statusBadge(s){return `<span class="badge ${s.toLowerCase()}">${s}</span>`}
function layout(content){
app.innerHTML=`<div class="shell">
<aside class="side desktop"><div class="logo"><i></i>KUKUZA</div>${sideLinks()}</aside>
<header class="top"><button class="icon" onclick="openDrawer()">☰</button><div class="logo"><i></i>KUKUZA</div><div class="topright"><button class="icon">🔔<em class="notify"></em></button><button class="user" onclick="location.hash='profile'">KP</button></div></header>
<main class="container">${content}</main>
<nav class="nav">${navLinks()}</nav><div class="toast"></div><div id="drawer" class="drawer" onclick="if(event.target.id==='drawer')closeDrawer()"><div class="drawerbox"><div class="logo" style="margin-bottom:25px"><i></i>KUKUZA</div>${sideLinks()}<button class="drawerlink" onclick="logout()">↪ Logout</button></div></div>
</div>`;
}
function sideLinks(){
return `<button class="drawerlink" onclick="go('dashboard')">⌂ &nbsp; Dashboard</button>
<button class="drawerlink" onclick="go('services')">▤ &nbsp; Services</button>
<button class="drawerlink" onclick="go('new-order')">＋ &nbsp; New Order</button>
<button class="drawerlink" onclick="go('orders')">↺ &nbsp; Orders</button>
<button class="drawerlink" onclick="go('funds')">▣ &nbsp; Add Funds</button>
<button class="drawerlink" onclick="go('support')">◉ &nbsp; Support</button>
<button class="drawerlink" onclick="go('profile')">● &nbsp; Profile</button>
<button class="drawerlink" onclick="go('admin')">⚙ &nbsp; Admin</button>`;
}
function navLinks(){return `<button onclick="go('support')" class="${route()==='support'?'active':''}"><b>◉</b><small>Support</small></button><button onclick="go('services')" class="${route()==='services'?'active':''}"><b>▤</b><small>Services</small></button><button class="new" onclick="go('new-order')"><b>＋</b><small>New Order</small></button><button onclick="go('orders')" class="${route()==='orders'?'active':''}"><b>↺</b><small>Orders</small></button><button onclick="go('funds')" class="${route()==='funds'?'active':''}"><b>▣</b><small>Add Funds</small></button>`}
function go(r){location.hash=r}
function openDrawer(){document.getElementById("drawer").classList.add("open")} function closeDrawer(){document.getElementById("drawer").classList.remove("open")}
function render(){
if(localStorage.getItem("kukuza_auth")!=="1" && route()!=="login" && route()!=="register"){login();return}
const pages={dashboard,services,newOrder,orders,funds,support,profile,admin};
(pages[route()]||dashboard)();
}
function login(){
app.innerHTML=`<div class="auth"><div class="authbox"><div class="logo"><i></i>KUKUZA</div><h1>Welcome back</h1><p>Login kwenye account yako ili kuendelea.</p><form class="form" onsubmit="event.preventDefault();localStorage.setItem('kukuza_auth','1');go('dashboard')"><div class="field"><label>Email</label><input required type="email" placeholder="you@example.com"></div><div class="field"><label>Password</label><input required type="password" placeholder="••••••••"></div><button class="btn primary full">Login</button></form><p style="margin-top:16px;text-align:center">Huna account? <a href="#register" style="color:#6d3df5;font-weight:800">Register</a></p></div></div>`}
function register(){
app.innerHTML=`<div class="auth"><div class="authbox"><div class="logo"><i></i>KUKUZA</div><h1>Create account</h1><p>Fungua account mpya kwa ajili ya kutumia services.</p><form class="form" onsubmit="event.preventDefault();localStorage.setItem('kukuza_auth','1');go('dashboard')"><div class="field"><label>Full name</label><input required placeholder="Jina lako"></div><div class="field"><label>Email</label><input required type="email" placeholder="you@example.com"></div><div class="field"><label>Password</label><input required type="password" placeholder="••••••••"></div><button class="btn primary full">Create Account</button></form><p style="margin-top:16px;text-align:center">Una account? <a href="#login" style="color:#6d3df5;font-weight:800">Login</a></p></div></div>`}
function dashboard(){
layout(`<section class="hero"><div class="small">Welcome back</div><h1>Kukuza Panel</h1><p>Manage services, orders, balance na support sehemu moja.</p><div class="hero-row"><div><div class="small">Available Balance</div><div class="balance">${money(DB.user.balance)}</div></div><button class="btn green" onclick="go('funds')">+ Add Funds</button></div></section>
<div class="grid"><div class="stat">🛒<b>${DB.orders.length}</b><span>Total Orders</span></div><div class="stat">▤<b>${DB.services.length}</b><span>Services</span></div><div class="stat">⏳<b>${DB.orders.filter(o=>o.status==='Processing').length}</b><span>Processing</span></div><div class="stat">✓<b>${DB.orders.filter(o=>o.status==='Completed').length}</b><span>Completed</span></div></div>
<div class="card"><div class="head"><h3>Quick Actions</h3></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" onclick="go('new-order')">New Order</button><button class="btn light" onclick="go('services')">Services</button><button class="btn green" onclick="go('funds')">Add Funds</button></div></div>
<div class="card"><div class="head"><h3>Recent Orders</h3><button class="muted" onclick="go('orders')">View all</button></div><div class="list">${DB.orders.slice(0,3).map(orderRow).join("")}</div></div>`);
}
function orderRow(o){return `<div class="row"><div class="left"><div class="avatarico">📦</div><div><div class="name">${esc(o.service)}</div><div class="sub">${esc(o.id)} · ${Number(o.qty).toLocaleString()} · ${esc(o.date)}</div></div></div>${statusBadge(o.status)}</div>`}
function services(){
layout(`<div class="title">Services</div><div class="tabs"><button class="active" onclick="filterServices('All',this)">All</button><button onclick="filterServices('Instagram',this)">Instagram</button><button onclick="filterServices('TikTok',this)">TikTok</button><button onclick="filterServices('YouTube',this)">YouTube</button></div><div id="serviceList" class="list">${serviceRows(DB.services)}</div>`);
}
function serviceRows(arr){return arr.map(s=>`<div class="service"><div><h4>${esc(s.name)}</h4><p>${s.cat} · Min ${s.min.toLocaleString()} · Max ${s.max.toLocaleString()}</p></div><div class="price">${money(s.price)}/1K</div></div>`).join("")}
function filterServices(cat,el){document.querySelectorAll(".tabs button").forEach(b=>b.classList.remove("active"));el.classList.add("active");document.getElementById("serviceList").innerHTML=serviceRows(cat==="All"?DB.services:DB.services.filter(s=>s.cat===cat))}
function newOrder(){
layout(`<div class="title">New Order</div><div class="card"><div class="form"><div class="field"><label>Category</label><select id="category" onchange="syncServices()"><option>Instagram</option><option>TikTok</option><option>YouTube</option></select></div><div class="field"><label>Service</label><select id="service" onchange="calc()">${DB.services.map(s=>`<option value="${s.id}">${esc(s.name)} — ${money(s.price)}/1K</option>`)}</select></div><div class="field"><label>Link</label><input id="link" placeholder="https://instagram.com/..."></div><div class="field"><label>Quantity</label><input id="qty" type="number" placeholder="100" oninput="calc()"></div><div class="field"><label>Charge</label><input id="charge" value="TSh 0" readonly></div><button class="btn green full" onclick="placeOrder()">Place Order</button></div></div>`);
}
function syncServices(){const cat=document.getElementById("category").value;document.getElementById("service").innerHTML=DB.services.filter(s=>s.cat===cat).map(s=>`<option value="${s.id}">${esc(s.name)} — ${money(s.price)}/1K</option>`).join("");calc()}
function calc(){const s=DB.services.find(x=>x.id==document.getElementById("service").value),q=Number(document.getElementById("qty").value||0);document.getElementById("charge").value=money(q*s.price/1000)}
function placeOrder(){const link=document.getElementById("link").value.trim(),q=Number(document.getElementById("qty").value),s=DB.services.find(x=>x.id==document.getElementById("service").value),cost=q*s.price/1000;if(!link||q<s.min||q>s.max){toast(`Quantity must be ${s.min.toLocaleString()}–${s.max.toLocaleString()}`);return}if(cost>DB.user.balance){toast("Insufficient balance — add funds first");return}DB.user.balance-=cost;DB.orders.unshift({id:"#"+(1009+DB.orders.length),service:s.name,qty:q,status:"Pending",link,date:"Just now"});toast("Order created successfully");setTimeout(()=>go("orders"),500)}
function orders(){
layout(`<div class="title">Order Logs</div><div class="tabs"><button class="active">All</button><button>Pending</button><button>Processing</button><button>Completed</button></div><div class="card"><div class="list">${DB.orders.map(orderRow).join("")}</div></div>`);
}
function funds(){
layout(`<div class="title">Add Funds</div><div class="hero"><div class="small">Current Balance</div><div class="balance">${money(DB.user.balance)}</div></div><div class="card"><div class="form"><div class="field"><label>Amount (TSh)</label><input id="amount" type="number" placeholder="10,000"></div><div class="field"><label>Payment Method</label><select id="method"><option>M-Pesa</option><option>Airtel Money</option><option>Tigo Pesa</option><option>Bank</option></select></div><button class="btn green full" onclick="addFunds()">Continue to Payment</button></div></div><div class="card"><div class="notice">Demo mode: payment gateway haijaunganishwa bado. Hatua inayofuata tunaunganisha payment API halisi.</div></div>`);
}
function addFunds(){const a=Number(document.getElementById("amount").value);if(a<=0){toast("Enter amount");return}DB.user.balance+=a;toast("Demo balance updated");setTimeout(()=>funds(),400)}
function support(){
layout(`<div class="title">Support</div><div class="card"><form class="form" onsubmit="event.preventDefault();DB.tickets.push({id:"#T"+(DB.tickets.length+1),subject:document.getElementById('subject').value,status:'Open'});toast('Ticket submitted');setTimeout(()=>support(),400)"><div class="field"><label>Subject</label><select id="subject"><option>Order</option><option>Payment</option><option>Account</option><option>Other</option></select></div><div class="field"><label>Order ID</label><input placeholder="#1008"></div><div class="field"><label>Message</label><textarea placeholder="Describe your issue..."></textarea></div><button class="btn primary full">Submit Ticket</button></form></div><div class="card"><div class="head"><h3>My Tickets</h3></div>${DB.tickets.length?DB.tickets.map(t=>`<div class="row"><span>${t.id} · ${t.subject}</span>${statusBadge(t.status)}</div>`).join(""):'<div class="muted">No tickets yet.</div>'}</div>`);
}
function profile(){
layout(`<div class="title">Profile</div><div class="card"><div class="form"><div class="field"><label>Full Name</label><input value="${esc(DB.user.name)}"></div><div class="field"><label>Email</label><input value="${esc(DB.user.email)}"></div><button class="btn primary" onclick="toast('Profile saved')">Save Changes</button><button class="btn danger" onclick="logout()">Logout</button></div></div>`);
}
function admin(){
layout(`<div class="title">Admin Dashboard</div><div class="grid"><div class="stat">👥<b>1</b><span>Users</span></div><div class="stat">📦<b>${DB.orders.length}</b><span>Orders</span></div><div class="stat">▤<b>${DB.services.length}</b><span>Services</span></div><div class="stat">💰<b>${money(DB.user.balance)}</b><span>Balance</span></div></div>
<div class="card"><div class="head"><h3>Services Management</h3><button class="btn primary" onclick="addService()">+ Service</button></div><table class="table"><thead><tr><th>Service</th><th>Category</th><th>Price/1K</th><th></th></tr></thead><tbody>${DB.services.map(s=>`<tr><td>${esc(s.name)}</td><td>${s.cat}</td><td>${money(s.price)}</td><td><button class="muted" onclick="removeService(${s.id})">Delete</button></td></tr>`).join("")}</tbody></table></div>
<div class="card"><div class="head"><h3>Orders</h3></div>${DB.orders.map(orderRow).join("")}</div>`);
}
function addService(){const name=prompt("Service name?");if(!name)return;const cat=prompt("Category?","Instagram");const price=Number(prompt("Price per 1K?","10000"));if(!price)return;DB.services.push({id:Date.now(),name,cat,price,min:100,max:1000000});admin()}
function removeService(id){const s=DB.services.find(x=>x.id===id);if(!s)return;if(confirm("Delete "+s.name+"?")){DB.services=DB.services.filter(x=>x.id!==id);admin()}}
function logout(){localStorage.removeItem("kukuza_auth");go("login")}
window.addEventListener("hashchange",render);
render();