# Kukuza Website — Full Frontend Starter

This project contains the complete mobile-first website/panel structure requested from the screen recording.

## Pages
- Login
- Register
- Dashboard
- Services
- New Order
- Orders / Order Logs
- Add Funds
- Support / Tickets
- Profile
- Admin Dashboard

## Run locally
Open `index.html` in a browser.

For production, connect a backend/database and payment provider. The current payment and authentication flows are demo/local-browser flows.

## Production architecture recommended
Frontend: this UI or React/Next.js
Backend: Node.js/Express or Laravel
Database: MySQL/PostgreSQL
Authentication: secure server sessions/JWT
Payments: official Tanzania mobile-money/bank payment API
Hosting: VPS/cloud hosting + domain + HTTPS

Do not put secret API keys inside `app.js`.
